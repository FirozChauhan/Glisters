window.CONFIG = {
  "worker": ""
};
